package com.zzw.ShoppingCart.servlet;

import com.alibaba.fastjson.JSONObject;
import com.sun.org.apache.xpath.internal.operations.Or;
import com.zzw.ShoppingCart.entity.Order;
import com.zzw.product.dao.impl.mysql.ProductDaoImpl;
import com.zzw.product.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(name = "AddProductServlet",urlPatterns = "/shopping/addProduct")
public class AddProductServlet extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        super.service(req, resp);
    }
    /**
     * 添加商品到购物车
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        JSONObject object = new JSONObject();
        String obj = request.getParameter("AddProductID");
        String count = request.getParameter("ProductCount");

        if(obj==null || count == null){
            object.put("AddStatus",false);
            object.put("Error","商品编号或数量不明！");
            response.getWriter().println(object.toJSONString());
            return;
        }
        Integer productID = Integer.parseInt(obj);
        Product product = (new ProductDaoImpl()).getProductById(productID);
        Integer productCount = Integer.parseInt(count);
        Order order = new Order(product,productCount);
        if(request.getSession().getAttribute("Cars") == null){
            //第一次添加购物车
            Map<Integer,Order> shoppingCar = new HashMap<Integer,Order>();
            shoppingCar.put(productID,order);
            request.getSession().setAttribute("Cars",shoppingCar);
        }else{
            Map<Integer,Order> shoppingCar =(Map<Integer,Order>)request.getSession().getAttribute("Cars");
            if(shoppingCar.keySet().contains(productID)){
               // 订单中商品已经存在 那么增加数量
               Order increseOrder = shoppingCar.get(productID);
               increseOrder.setCount(increseOrder.getCount() + productCount);
            }else{
                shoppingCar.put(productID,order);
            }
        }
        object.put("AddStatus",true);
        object.put("Error","status 200");

        response.getWriter().println(object.toJSONString());
    }

    /**
     * 返回购物车中的物品
     * @param  request
     * @param  response
     * @throws ServletException
     * @throws IOException
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        JSONObject obj = new JSONObject();
        if(request.getSession().getAttribute("Cars") == null){
            //购物车没有物品 为空
            obj.put("HasProduct",false);
            obj.put("Status","购物车为空");
        }else{
            Map<Integer,Order> shoppingCar =(Map<Integer,Order>)request.getSession().getAttribute("Cars");
            if(shoppingCar.keySet().isEmpty()){
                obj.put("Status","购物车为空");
                obj.put("HasProduct",false);
            }else{
                request.getSession().setMaxInactiveInterval(60*60);

                obj.put("Status","购物车不为空");
                obj.put("HasProduct",true);

                int count = 0;
                float meonyAll = 0.0f;
                //商品件数
                List<Order> orders = new ArrayList<Order>();

                for (Integer val :shoppingCar.keySet()) {
                    Order order = (Order)shoppingCar.get(val);
                    count += order.getCount();
                    meonyAll += (order.getCount() * order.getProduct().getPrice());
                    orders.add(order);
                }
                obj.put("data",orders);
                obj.put("Count",count);
                obj.put("meonyAll",meonyAll);
            }
        }
        response.setContentType("text/json; charset=utf-8");
        response.getWriter().println(obj.toJSONString());
    }
}
