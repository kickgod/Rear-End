package com.zzw.ShoppingCart.servlet;

import com.alibaba.fastjson.JSONObject;
import com.zzw.ShoppingCart.entity.Order;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet(name = "deleteProductServlet",urlPatterns = "/shopping/deleteProduct")
public class deleteProductServlet extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        super.service(req, resp);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/json; charset=utf-8");
        JSONObject obj = new JSONObject();

        String val = request.getParameter("ProductKey");
        if(request.getSession().getAttribute("Cars") == null){
            obj.put("isSuccess",false);
            obj.put("info","购物车为空没有商品！");
        }else{
            Map<Integer,Order> shoppingCar = (Map<Integer,Order>)request.getSession().getAttribute("Cars");
            if(shoppingCar.keySet().isEmpty()){
                obj.put("isSuccess",false);
                obj.put("info","购物车为空没有商品！");
            }else{
                if(shoppingCar.keySet().contains(Integer.parseInt(val))){
                    shoppingCar.remove(Integer.parseInt(val));
                    obj.put("isSuccess",true);
                    obj.put("info","删除成功！");
                }else{
                    obj.put("isSuccess",false);
                    obj.put("info","商品并不在购物车中！");
                }
            }
        }
        response.getWriter().println(obj.toJSONString());
    }
}
