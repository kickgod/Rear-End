package com.zzw.ShoppingCart.entity;

import com.zzw.product.entity.Product;

public class Order {
    private Product product;

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Order() {
    }

    public Order(Product product, int count) {
        this.product = product;
        Count = count;
    }

    public int getCount() {
        return Count;
    }

    public void setCount(int count) {
        Count = count;
    }

    private int Count;
}
