package com.zzw.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginFilter implements Filter   {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
			throws IOException, ServletException {

		System.out.println(((HttpServletRequest)servletRequest).getRequestURI());

		if(!((HttpServletRequest)servletRequest).getRequestURI().equals("/experience/index.html") ) {
			HttpSession session = ((HttpServletRequest)servletRequest).getSession();

			if (session.getAttribute("UserName") == null){
				//((HttpServletRequest)servletRequest).getRequestDispatcher("index.html").forward(servletRequest,servletResponse);
				((HttpServletResponse)servletResponse).sendRedirect("index.html"); //再次请求
			}else {
				System.out.println((String) session.getAttribute("UserName"));
				filterChain.doFilter(servletRequest,servletResponse);
			}
		}else {
			filterChain.doFilter(servletRequest,servletResponse);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
