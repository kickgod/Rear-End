package com.zzw.product.entity;

public class Product {
    public int productID;
    public int typeID;
    public String productName;
    public float price;
    public int monthlySale;
    public int review;
    public int saveCount;
    public int integral;
    public String picture01;
    public String picture2;
    public String picture3;
    public String picture4;
    public String picture5;

    public Product(int productID, int typeID, String productName, float price, int monthlySale, int review, int saveCount, int integral, String picture01, String picture2, String picture3, String picture4, String picture5) {
        this.productID = productID;
        this.typeID = typeID;
        this.productName = productName;
        this.price = price;
        this.monthlySale = monthlySale;
        this.review = review;
        this.saveCount = saveCount;
        this.integral = integral;
        this.picture01 = picture01;
        this.picture2 = picture2;
        this.picture3 = picture3;
        this.picture4 = picture4;
        this.picture5 = picture5;
    }

    public Product(){

    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getTypeID() {
        return typeID;
    }

    public void setTypeID(int typeID) {
        this.typeID = typeID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getMonthlySale() {
        return monthlySale;
    }

    public void setMonthlySale(int monthlySale) {
        this.monthlySale = monthlySale;
    }

    public int getReview() {
        return review;
    }

    public void setReview(int review) {
        this.review = review;
    }

    public int getSaveCount() {
        return saveCount;
    }

    public void setSaveCount(int saveCount) {
        this.saveCount = saveCount;
    }

    public int getIntegral() {
        return integral;
    }

    public void setIntegral(int integral) {
        this.integral = integral;
    }

    public String getPicture01() {
        return picture01;
    }

    public void setPicture01(String picture01) {
        this.picture01 = picture01;
    }

    public String getPicture2() {
        return picture2;
    }

    public void setPicture2(String picture2) {
        this.picture2 = picture2;
    }

    public String getPicture3() {
        return picture3;
    }

    public void setPicture3(String picture3) {
        this.picture3 = picture3;
    }

    public String getPicture4() {
        return picture4;
    }

    public void setPicture4(String picture4) {
        this.picture4 = picture4;
    }

    public String getPicture5() {
        return picture5;
    }

    public void setPicture5(String picture5) {
        this.picture5 = picture5;
    }
}
