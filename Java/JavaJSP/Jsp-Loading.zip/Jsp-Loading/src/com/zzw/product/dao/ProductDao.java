package com.zzw.product.dao;

import com.zzw.product.entity.Product;
import com.zzw.product.entity.ProductType;

import java.util.List;

public interface ProductDao {


    List<ProductType> getProductTypes();

    List<ProductType> getProductTypes(int count);

    List<Product> getProducts();

    List<Product> getProducts(int count);

    List<Product> getProductsByType(ProductType type,int count);

    List<Product> getProductsByTypeOffset(ProductType type,int offset,int count);

    Product getProductById(int id);

    /**
     * 返回所有的商品数量
     * @return 商品数量
     */
    int getProductCount();

    /**
     * 返回某种类型的商品的总的数据量
     * @param type 商品总类
     * @return int 商品数量
     */
    int getProductCount(ProductType type );

    /**
     * 返回第几页的所有数据
     * @param pageIndex 第几页
     * @param pageEntityCount 每一页多少个数据项
     * @return List<Product>
     */
    List<Product> getProductByPage(int pageIndex,int pageEntityCount);

    /**
     * @param pageIndex 第几页
     * @param pageEntityCount 每页数量
     * @param type 类型样式
     * @return 产品集合
     */
    List<Product> getProductByPage(int pageIndex,int pageEntityCount,ProductType type);

    /**
     * 查询商品根据商品的名称
     * @param key 商品名称关键字
     * @return 产品集合
     */
    List<Product> getProductByNameKey(String key);











}
