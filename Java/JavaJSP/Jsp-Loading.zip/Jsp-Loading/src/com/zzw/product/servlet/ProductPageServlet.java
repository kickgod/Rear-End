package com.zzw.product.servlet;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zzw.product.dao.ProductDao;
import com.zzw.product.dao.impl.mysql.ProductDaoImpl;
import com.zzw.product.entity.Product;
import com.zzw.product.entity.ProductType;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ProductPageServlet",urlPatterns = "/product/productPage")
public class ProductPageServlet extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        super.service(req, resp);
    }

    /**
     * 处理分页请求 初始化
     *
     * 请求 商品类型
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer typeID = Integer.parseInt(request.getParameter("TypeID"));
        Integer everyPageCount = Integer.parseInt(request.getParameter("everyPageCount"));
        Integer pageIndex = Integer.parseInt(request.getParameter("pageIndex"));
        ProductDao dao = new ProductDaoImpl();
        List<Product> products;
        if(typeID < 0){
             products = dao.getProductByPage(pageIndex,everyPageCount);
        }else{
            ProductType type = new ProductType();
            type.setTypeID(typeID);
            products = dao.getProductByPage(pageIndex,everyPageCount,type);
        }
        String result = JSON.toJSONString(products);

        response.getWriter().println(result);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer typeID = Integer.parseInt(request.getParameter("TypeID"));
        Integer everyPageCount = Integer.parseInt(request.getParameter("everyPageCount"));
        int count ;
        ProductDao dao = new ProductDaoImpl();

        if(typeID < 0){
            //没有类型
            count = dao.getProductCount();
        }else{
            ProductType type = new ProductType();
            type.setTypeID(typeID);
            count = dao.getProductCount(type);
        }
        int pageCount = count / everyPageCount;

        if(count % everyPageCount > 0){
            pageCount++;
        }
        JSONObject obj = new JSONObject();
        obj.put("pageCount",pageCount);
        response.getWriter().println(obj.toJSONString());

    }
}
