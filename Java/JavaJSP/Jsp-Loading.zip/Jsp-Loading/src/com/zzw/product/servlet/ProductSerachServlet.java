package com.zzw.product.servlet;

import com.zzw.product.dao.ProductDao;
import com.zzw.product.dao.impl.mysql.ProductDaoImpl;
import com.zzw.product.entity.Product;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Response;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ProductSerachServlet",urlPatterns = "/product/Search")
public class ProductSerachServlet extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        super.service(req, resp);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String keyName = request.getParameter("ProductNameKey");
        ProductDao dao =new ProductDaoImpl();
        if(keyName == null || keyName.equals("")){
            request.getSession().setAttribute("list",null);
        }else{
            List<Product> products =  dao.getProductByNameKey(keyName);
            request.getSession().setAttribute("list",products);
        }
        System.out.println(request.getContextPath());
        response.sendRedirect(request.getContextPath()+"/SearchResult.jsp");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


    }
}
