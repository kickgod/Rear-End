package com.zzw.product.servlet;

import com.alibaba.fastjson.JSON;
import com.zzw.product.dao.ProductDao;
import com.zzw.product.dao.impl.mysql.ProductDaoImpl;
import com.zzw.product.entity.ProductType;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "ProductGetByTypeCountServlet",urlPatterns = "/product/getProductByType")
public class ProductGetByTypeCountServlet extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        super.service(req, resp);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/json; charset=utf-8");
        int count = Integer.parseInt(request.getParameter("count"));
        int type = Integer.parseInt(request.getParameter("typeID"));
        ProductDao dao = new ProductDaoImpl();
        ProductType p_type = new ProductType();
        p_type.setTypeID(type);
        String result = JSON.toJSONString(dao.getProductsByType(p_type,count));
        response.getWriter().println(result);
    }
}
