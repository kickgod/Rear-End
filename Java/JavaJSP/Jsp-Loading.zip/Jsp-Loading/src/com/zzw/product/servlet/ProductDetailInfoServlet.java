package com.zzw.product.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "ProductDetailInfoServlet",urlPatterns = "/product/detail")
public class ProductDetailInfoServlet extends HttpServlet {

    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=UTF-8");
        super.service(req, resp);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer productID = Integer.parseInt(request.getParameter("productID"));
        HttpSession session = request.getSession();
        session.setAttribute("shooseID",productID);
        response.sendRedirect( request.getContextPath()+ "/description.html");
    }
}
