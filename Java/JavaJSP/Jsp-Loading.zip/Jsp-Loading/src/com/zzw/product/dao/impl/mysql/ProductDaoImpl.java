package com.zzw.product.dao.impl.mysql;

import com.zzw.dao.BaseDao;
import com.zzw.dao.ResultSetProcessor;
import com.zzw.product.dao.ProductDao;
import com.zzw.product.entity.Product;
import com.zzw.product.entity.ProductType;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductDaoImpl extends BaseDao implements ProductDao {

    @Override
    public List<ProductType> getProductTypes() {
        String sql = "select * from producttype";
        List<ProductType> list = (List<ProductType>)executeQuery(resultSet -> {
            List<ProductType> types = new ArrayList<>();
            while (resultSet.next()){
                int typeID = resultSet.getInt("TypeID");
                String typeName = resultSet.getString("TypeName");
                int typeStatus = resultSet.getInt("TypeStatus");

                ProductType type = new ProductType(typeID,typeName,typeStatus);
                types.add(type);
            }
            return types;
        },sql);
        return  list;
    }

    @Override
    public List<ProductType> getProductTypes(int count) {
        String sql = "SELECT * FROM producttype  LIMIT 0, ?";
        List<ProductType> list = (List<ProductType>)executeQuery(resultSet -> {
            List<ProductType> types = new ArrayList<>();
            while (resultSet.next()){
                int typeID = resultSet.getInt("TypeID");
                String typeName = resultSet.getString("TypeName");
                int typeStatus = resultSet.getInt("TypeStatus");
                ProductType type = new ProductType(typeID,typeName,typeStatus);
                types.add(type);
            }
            return types;
        },sql,count);
        return  list;
    }

    @Override
    public List<Product> getProducts() {
        String sql = " select * from product";
        List<Product> products = (List<Product>)executeQuery(resultSet-> {
            List<Product> products_ = new ArrayList<>();
            while (resultSet.next()){
                int productID      = resultSet.getInt("ProductID");
                int TypeID         = resultSet.getInt("TypeID");
                String ProductName = resultSet.getString("ProductName");
                float price        = resultSet.getFloat("Price");
                int MonthlySale    = resultSet.getInt("MonthlySale");
                int Review         = resultSet.getInt("Review");
                int SaveCount      = resultSet.getInt("SaveCount");
                int integral       = resultSet.getInt("integral");
                String Picture01   = resultSet.getString("Picture01");
                String Picture2    = resultSet.getString("Picture2");
                String Picture3    = resultSet.getString("Picture3");
                String Picture4    = resultSet.getString("Picture4");
                String Picture5    = resultSet.getString("Picture5");
                Product p1 = new Product(productID,TypeID,ProductName,price,MonthlySale,Review,SaveCount,integral,Picture01,Picture2,
                        Picture3,Picture4,Picture5);
                products_.add(p1);
            }
            return products_;
        },sql);
        return products;
    }

    @Override
    public List<Product> getProducts(int count) {
        String sql = " SELECT * FROM product LIMIT 0,?";
        List<Product> products = (List<Product>)executeQuery(resultSet-> {
            List<Product> products_ = new ArrayList<>();
            while (resultSet.next()){
                int productID      = resultSet.getInt("ProductID");
                int TypeID         = resultSet.getInt("TypeID");
                String ProductName = resultSet.getString("ProductName");
                float price        = resultSet.getFloat("Price");
                int MonthlySale    = resultSet.getInt("MonthlySale");
                int Review         = resultSet.getInt("Review");
                int SaveCount      = resultSet.getInt("SaveCount");
                int integral       = resultSet.getInt("integral");
                String Picture01   = resultSet.getString("Picture01");
                String Picture2    = resultSet.getString("Picture2");
                String Picture3    = resultSet.getString("Picture3");
                String Picture4    = resultSet.getString("Picture4");
                String Picture5    = resultSet.getString("Picture5");
                Product p1 = new Product(productID,TypeID,ProductName,price,MonthlySale,Review,SaveCount,integral,Picture01,Picture2,
                        Picture3,Picture4,Picture5);
                products_.add(p1);
            }
            return products_;
        },sql,count);
        return products;
    }

    @Override
    public List<Product> getProductsByType(ProductType type,int count) {
        String sql = "SELECT * FROM product where TypeID = ? LIMIT 0 ,?";
        List<Product> products = (List<Product>)executeQuery(resultSet-> {
            List<Product> products_ = new ArrayList<>();
            while (resultSet.next()){
                int productID      = resultSet.getInt("ProductID");
                int TypeID         = resultSet.getInt("TypeID");
                String ProductName = resultSet.getString("ProductName");
                float price        = resultSet.getFloat("Price");
                int MonthlySale    = resultSet.getInt("MonthlySale");
                int Review         = resultSet.getInt("Review");
                int SaveCount      = resultSet.getInt("SaveCount");
                int integral       = resultSet.getInt("integral");
                String Picture01   = resultSet.getString("Picture01");
                String Picture2    = resultSet.getString("Picture2");
                String Picture3    = resultSet.getString("Picture3");
                String Picture4    = resultSet.getString("Picture4");
                String Picture5    = resultSet.getString("Picture5");
                Product p1 = new Product(productID,TypeID,ProductName,price,MonthlySale,Review,SaveCount,integral,Picture01,Picture2,
                        Picture3,Picture4,Picture5);
                products_.add(p1);
            }
            return products_;
        },sql,type.getTypeID(),count);
        return products;
    }

    @Override
    public List<Product> getProductsByTypeOffset(ProductType type, int offset, int count) {
        return null;
    }

    @Override
    public Product getProductById(int id) {
        String sql = "SELECT * FROM product where  ProductID = ?";
        Product result =(Product)executeQuery(new ResultSetProcessor() {
            @Override
            public Object process(ResultSet resultSet) throws SQLException {
                if(resultSet.next()) {
                    int productID      = resultSet.getInt("ProductID");
                    int TypeID         = resultSet.getInt("TypeID");
                    String ProductName = resultSet.getString("ProductName");
                    float price        = resultSet.getFloat("Price");
                    int MonthlySale    = resultSet.getInt("MonthlySale");
                    int Review         = resultSet.getInt("Review");
                    int SaveCount      = resultSet.getInt("SaveCount");
                    int integral       = resultSet.getInt("integral");
                    String Picture01   = resultSet.getString("Picture01");
                    String Picture2    = resultSet.getString("Picture2");
                    String Picture3    = resultSet.getString("Picture3");
                    String Picture4    = resultSet.getString("Picture4");
                    String Picture5    = resultSet.getString("Picture5");
                    Product p1 = new Product(productID,TypeID,ProductName,price,MonthlySale,Review,SaveCount,integral,Picture01,Picture2,
                    Picture3,Picture4,Picture5);
                    return p1;
                }
                return null;
            }
        },sql,id);
        return result;
    }

    @Override
    public int getProductCount() {
        String sql = "select count(*) as count from product";
        int productCount = (Integer)executeQuery((rs)->{
            rs.next();
            int count = rs.getInt(1);
            return new Integer(count);
        },sql);
        return productCount;
    }

    @Override
    public int getProductCount(ProductType type) {
        String sql = "select count(*) as count from product where  TypeID = ?";
        int productCount = (Integer)executeQuery((rs)->{
            rs.next();
            int count = rs.getInt(1);
            return new Integer(count);
        },sql,type.getTypeID());
        return productCount;
    }

    @Override
    public List<Product> getProductByPage(int pageIndex, int pageEntityCount) {
        if(pageIndex < 1){
            return null;
        }
        String sql = "SELECT * FROM product LIMIT ? , ?";
        List<Product> products = (List<Product>)executeQuery(resultSet-> {
            List<Product> products_ = new ArrayList<>();
            while (resultSet.next()){
                int productID      = resultSet.getInt("ProductID");
                int TypeID         = resultSet.getInt("TypeID");
                String ProductName = resultSet.getString("ProductName");
                float price        = resultSet.getFloat("Price");
                int MonthlySale    = resultSet.getInt("MonthlySale");
                int Review         = resultSet.getInt("Review");
                int SaveCount      = resultSet.getInt("SaveCount");
                int integral       = resultSet.getInt("integral");
                String Picture01   = resultSet.getString("Picture01");
                String Picture2    = resultSet.getString("Picture2");
                String Picture3    = resultSet.getString("Picture3");
                String Picture4    = resultSet.getString("Picture4");
                String Picture5    = resultSet.getString("Picture5");
                Product p1 = new Product(productID,TypeID,ProductName,price,MonthlySale,Review,SaveCount,integral,Picture01,Picture2,
                        Picture3,Picture4,Picture5);
                products_.add(p1);
            }
            return products_;
        },sql,(pageIndex - 1)*pageEntityCount,pageEntityCount);
        return products;
    }

    @Override
    public List<Product> getProductByPage(int pageIndex, int pageEntityCount, ProductType type) {
        if(pageIndex < 1){
            return null;
        }

        String sql = "SELECT * FROM product where TypeID = ? LIMIT ? , ?";
        List<Product> products = (List<Product>)executeQuery(resultSet-> {
            List<Product> products_ = new ArrayList<>();
            while (resultSet.next()){
                int productID      = resultSet.getInt("ProductID");
                int TypeID         = resultSet.getInt("TypeID");
                String ProductName = resultSet.getString("ProductName");
                float price        = resultSet.getFloat("Price");
                int MonthlySale    = resultSet.getInt("MonthlySale");
                int Review         = resultSet.getInt("Review");
                int SaveCount      = resultSet.getInt("SaveCount");
                int integral       = resultSet.getInt("integral");
                String Picture01   = resultSet.getString("Picture01");
                String Picture2    = resultSet.getString("Picture2");
                String Picture3    = resultSet.getString("Picture3");
                String Picture4    = resultSet.getString("Picture4");
                String Picture5    = resultSet.getString("Picture5");
                Product p1 = new Product(productID,TypeID,ProductName,price,MonthlySale,Review,SaveCount,integral,Picture01,Picture2,
                        Picture3,Picture4,Picture5);
                products_.add(p1);
            }
            return products_;
        },sql,type.getTypeID(),(pageIndex - 1)*pageEntityCount,pageEntityCount);
        return products;
    }

    @Override
    public List<Product> getProductByNameKey(String key) {
        String sql = "select * from product where ProductName like ? ";
        List<Product> products = (List<Product>)executeQuery(resultSet-> {
            List<Product> products_ = new ArrayList<>();
            while (resultSet.next()){
                int productID      = resultSet.getInt("ProductID");
                int TypeID         = resultSet.getInt("TypeID");
                String ProductName = resultSet.getString("ProductName");
                float price        = resultSet.getFloat("Price");
                int MonthlySale    = resultSet.getInt("MonthlySale");
                int Review         = resultSet.getInt("Review");
                int SaveCount      = resultSet.getInt("SaveCount");
                int integral       = resultSet.getInt("integral");
                String Picture01   = resultSet.getString("Picture01");
                String Picture2    = resultSet.getString("Picture2");
                String Picture3    = resultSet.getString("Picture3");
                String Picture4    = resultSet.getString("Picture4");
                String Picture5    = resultSet.getString("Picture5");
                Product p1 = new Product(productID,TypeID,ProductName,price,MonthlySale,Review,SaveCount,integral,Picture01,Picture2,
                        Picture3,Picture4,Picture5);
                products_.add(p1);
            }
            return products_;
        },sql,"%" + key + "%");
        return products;
    }


}
