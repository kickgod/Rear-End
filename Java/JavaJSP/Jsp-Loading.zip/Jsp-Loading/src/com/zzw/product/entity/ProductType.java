package com.zzw.product.entity;

public class ProductType {
    private int TypeID;
    private String TypeName;
    private int TypeStatus;

    public int getTypeID() {
        return TypeID;
    }

    public void setTypeID(int typeID) {
        TypeID = typeID;
    }

    public String getTypeName() {
        return TypeName;
    }

    public void setTypeName(String typeName) {
        TypeName = typeName;
    }

    public int getTypeStatus() {
        return TypeStatus;
    }

    public void setTypeStatus(int typeStatus) {
        TypeStatus = typeStatus;
    }

    public ProductType() {

    }

    public ProductType(int typeID, String typeName, int typeStatus) {
        TypeID = typeID;
        TypeName = typeName;
        TypeStatus = typeStatus;
    }


}
