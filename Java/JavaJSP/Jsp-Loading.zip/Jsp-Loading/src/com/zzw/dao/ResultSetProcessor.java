package com.zzw.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface ResultSetProcessor {
	Object process(ResultSet rs) throws SQLException;
}
