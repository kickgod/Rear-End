package com.zzw.dao;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
//import java.util.Properties;
import java.util.Properties;

import javax.sql.DataSource;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BaseDao {
		 /*
		  public static String jdbUrl;

		  public static String DriverMysqlString="d";

		  public static String JdbcMysqlUrl =
			 "jdbc:mysql://127.0.0.1:3306/mydb?&characterEncoding=UTF-8&serverTimezone=UTC";


		  public Connection createConnection() {
			 try {
				return getConnection(DriverMysqlString,JdbcMysqlUrl,"root","root");
			 } catch (Exception e) {
				e.printStackTrace();
			 }
			 return null;
		  }


		  public static Connection getConnection(String driverClass,String jdbUrl,String user,String password)
		   throws Exception {
			  Driver driver=(Driver)Class.forName(driverClass).newInstance();
			  Properties info=new Properties();
			  info.put("user", user);
			  info.put("password", password);
			  Connection connection;
			  connection = (Connection) driver.connect(jdbUrl, info);
			  return  connection;
		  }

		*/
	
		public Connection createConnection() {
			Connection conn = null;
			Context ctx = null;
			// 获取连接并捕获异常
			try {
				ctx = new InitialContext();
				DataSource ds = (DataSource) ctx
						.lookup("java:comp/env/jdbc/registration");
				conn = ds.getConnection();
			} catch (NamingException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if(conn == null) {
				System.err.println("无法建立数据库连接。");
			}
			return conn;
		}
	
		public void closeAll(Connection conn, Statement stmt, ResultSet rs) {
			// 若结果集对象不为空，则关闭
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			// 若Statement对象不为空，则关闭
			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			// 若数据库连接对象不为空，则关闭
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

		public void closeAll(Connection conn, Statement stmt) {
			closeAll(conn, stmt, null);
		}

		/**
		 * 增、删、改操作
		 * 
		 * @param sql
		 *  sql语句
		 * @param params
		 *            参数数组
		 * @return 执行结果
		 */
		public int executeUpdate(String sql, Object... params) {
			int result = 0;
			Connection conn = null;
			PreparedStatement pstmt = null;
			try {
				conn = this.createConnection();
				if (conn != null && !conn.isClosed()) {
					pstmt = conn.prepareStatement(sql);
					if(params != null) {
						for (int i = 0; i < params.length; i++) {
							pstmt.setObject(i + 1, params[i]);
						}
					}
					result = pstmt.executeUpdate();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeAll(conn, pstmt);
			}
			return result;
		}

		public Object executeQuery(ResultSetProcessor processor, String sql,
				Object... params) {
			Object result = null;
			Connection conn = null;
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			try {
				conn = this.createConnection();
				if (conn != null && conn.isClosed() == false) {
					pstmt = conn.prepareStatement(sql);
					if(params != null) {
						for (int i = 0; i < params.length; i++) {
							pstmt.setObject(i + 1, params[i]);
						}
					}
					rs = pstmt.executeQuery();
					result = processor.process(rs);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				closeAll(conn, pstmt, rs);
			}
			return result;
		}
}
