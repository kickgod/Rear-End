package com.zzw.account.dao;

import com.zzw.account.entity.Account;

public interface AccountDao {
	int insertAccount(Account account);
	
	Account findAccountByID(String ID);
	
	Boolean UserIsRightCanLogin(Account account);
}
