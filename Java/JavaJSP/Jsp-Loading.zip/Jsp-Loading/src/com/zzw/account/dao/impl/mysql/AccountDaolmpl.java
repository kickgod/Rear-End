package com.zzw.account.dao.impl.mysql;


import java.sql.SQLException;


import com.zzw.account.dao.AccountDao;
import com.zzw.account.entity.Account;
import com.zzw.dao.BaseDao;
import com.zzw.dao.ResultSetProcessor;

public class AccountDaolmpl extends BaseDao implements AccountDao {

	@Override
	public int insertAccount(Account account) {
		String sql = "insert into Accounts(AccountID,AccountPasswrod,AccountName,AccountEmail,AccountDescription) values(?,?,?,?,?)";
		return executeUpdate(sql,
				account.getAccountID(),
				account.getPassword(),
				account.getAccountName(),
				account.getAccountEmail(),
				account.getAccountDescription());
	}

	@Override
	public Account findAccountByID(String accountID) {
		String sql = "select * from Accounts where AccountID = ?";
		Account account = (Account)executeQuery(new ResultSetProcessor() {
			@java.lang.Override
			public Object process(java.sql.ResultSet rs) throws SQLException {
				if(rs.next()) {
					String AccountID = rs.getString("AccountID");
					String AccountPasswrod = rs.getString("AccountPasswrod");
					String AccountName = rs.getString("AccountName");
					String AccountEmail = rs.getString("AccountEmail");
					String AccountDescription = rs.getString("AccountDescription");
					return new Account(AccountID,AccountPasswrod,AccountName,AccountEmail,AccountDescription);
				}
				return null;
			}
		}, sql, accountID);
		return account;
	}

	@Override
	public Boolean UserIsRightCanLogin(Account account) {
		String sql = "select * from Accounts where AccountID = ? and AccountPasswrod = ?";
		Account account_ = (Account)executeQuery(new ResultSetProcessor() {
			@java.lang.Override
			public Object process(java.sql.ResultSet rs) throws SQLException {
				if(rs.next()) {
					String AccountID = rs.getString("AccountID");
					String AccountPasswrod = rs.getString("AccountPasswrod");
					String AccountName = rs.getString("AccountName");
					String AccountEmail = rs.getString("AccountEmail");
					String AccountDescription = rs.getString("AccountDescription");
					return new Account(AccountID,AccountPasswrod,AccountName,AccountEmail,AccountDescription);
				}
				return null;
			}
		}, sql, account.getAccountID(),account.getPassword());
		return account_ != null;
	}

	
	
}
