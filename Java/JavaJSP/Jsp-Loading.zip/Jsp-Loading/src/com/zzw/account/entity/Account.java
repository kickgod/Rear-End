package com.zzw.account.entity;

public class Account {
	private String accountID;
	private String password;
	private String accountEmail;
	private String accountName;
	private String accountDescription;
	
	public Account() {
	
	}
	
	public Account(String accountID, String password, String accountEmail, String accountName,
			String accountDescription) {
		super();
		this.accountID = accountID;
		this.password = password;
		this.accountEmail = accountEmail;
		this.accountName = accountName;
		this.accountDescription = accountDescription;
	}


	public String getAccountID() {
		return accountID;
	}

	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccountEmail() {
		return accountEmail;
	}

	public void setAccountEmail(String accountEmail) {
		this.accountEmail = accountEmail;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getAccountDescription() {
		return accountDescription;
	}

	public void setAccountDescription(String accountDescription) {
		this.accountDescription = accountDescription;
	}
	

}
