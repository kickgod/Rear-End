package com.zzw.account.servlet;

import com.zzw.account.dao.AccountDao;
import com.zzw.account.dao.impl.mysql.AccountDaolmpl;
import com.zzw.account.entity.Account;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "UserRegisterServlet",urlPatterns = "/register")
public class UserRegisterServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        super.service(req, resp);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        String realName = request.getParameter("RealName");
        String UserName = request.getParameter("UserName");
        String Password = request.getParameter("Password");
        String UserEmail = request.getParameter("UserEmail");
        String userInfo = request.getParameter("userInfo");

        Account account = new Account(UserName,Password,UserEmail,realName,userInfo);
        AccountDao dao = new AccountDaolmpl();
        dao.insertAccount(account);
        response.sendRedirect("registerSuccess.html");

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
