package com.zzw.account.servlet;

import com.alibaba.fastjson.JSON;
import com.zzw.account.dao.AccountDao;
import com.zzw.account.dao.impl.mysql.AccountDaolmpl;
import com.zzw.account.entity.Account;
import com.zzw.entities.AccountState;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;


import static java.lang.System.out;

@WebServlet(name = "UserLoginServlet",urlPatterns = "/login")
public class UserLoginServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        super.service(req, resp);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");

        String UserName = request.getParameter("UserName");
        String userPassword = request.getParameter("UserPassword");
        String remenber = request.getParameter("remenber");

        System.out.println(remenber);
        Account account = new Account();
        account.setAccountID(UserName);
        account.setPassword(userPassword);
        AccountDao dao = new AccountDaolmpl();
        Boolean isRight = dao.UserIsRightCanLogin(account);
        if(isRight){
            HttpSession session = request.getSession();
            session.setAttribute("UserName",UserName);
            session.setAttribute("UserPassword",userPassword);
            out.println("登陆一次! 成功");
            if( remenber!= null &&remenber.equals(true)){
                //cookie 记住
                Cookie c_userName = new Cookie("UserName",UserName);
                Cookie c_userPassword = new Cookie("UserPassword",userPassword);
                response.addCookie(c_userName);
                response.addCookie(c_userPassword);
            }
            response.sendRedirect("index.html");

        }else{
            out.println("登陆一次！ 失败");
            response.sendRedirect("loginFail.html");
        }
    }


    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        AccountState state = new AccountState();
        response.setContentType("text/json; charset=utf-8"); //设置返回类型为json
        if( session.getAttribute("UserName") == null){
            //登陆失败
            state.hasLogin = false;

        }else{
            String userId = (String) session.getAttribute("UserName");
            String Password = (String) session.getAttribute("UserPassword");
            //保存一个小时 每次到主页延长session 一个小时的时间
            session.setMaxInactiveInterval(60*60);
            state.hasLogin = true;
            state.UserID = userId;
        }
        String result = JSON.toJSONString(state);
        response.getWriter().print(result);
    }
}
