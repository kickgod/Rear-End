package com.zzw.entities;


/**
 * 用户账户状态 作为JSON 数据 用户服务器和 HMTL页面 传递数据的中间媒介
 */
public class AccountState {
    public Boolean isLoginSuccess ; //是否成功登陆

    public Boolean hasLogin;   //是否登陆

    public Boolean hasRegister; //是否注册

    public Boolean isRegisterSuccess; //是否成功注册

    public String  loginErrorInfo;

    public String  rgisterErrorInfo;

    public Integer states;

    public String UserID;

    public  AccountState(){
        this.isRegisterSuccess = false;
        this.hasLogin = false;
        this.hasRegister = false;
        this.isLoginSuccess = false;
        this.loginErrorInfo = "登陆错误！ 长或或密码错误";
        this.rgisterErrorInfo = "注册错误！ 信息重复已注册,或信息不合格";
        this.states = 404;
        this.UserID = "";
    }

}
